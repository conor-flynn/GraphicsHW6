NOTE: There is information displayed in the console that is very important for understanding the different program states
	
Interpolation:
	- Play the animation (or drag the scrollbar around)
	- Click 'Save Frame' when you want to save a frame
		-- The the debug window, it will output what frame was saved, and how many frames are currently saved
	- Once you have frames, you can click 'Switch Display' and it will show the key frames
		-- My approach to displaying frames is probably different. If you hit play in order to play the animation, it will display the saved frame that is closest to the current timestep of the animation. This process rounds down. For example, if you have key frames {40, 60, 180, 200}, and the current timestep is 175, the chosen 'key-frame' will be shown as saved-frame 60. So all keyframes are not shown at once, but you can view them all.
	- Once you have 2 key frames, you can click 'Toggle Interpolation'
		-- When you reach the end of the designated interpolation range, it performs the interpolation against either the first or last posture of the total animation.
		-- If you only have a couple of interpolation points, it looks really bad. If you add an enormous amount of dense interpolation points, it looks identical to the other animation.
	
NOTE: There is information displayed in the console that is very important for understanding the different program states
		
(BUTTON) Switch Display - this button is a toggle
	Normal Mode:
		- dispays the animation (either the normal animaton, or the custom interpolation)
	KeyFrameMode:
		- displays the static key frames
		- the key frame closest to the current frame is displayed (rounds down to the nearest keyframe)
(BUTTON) Save Frame
	- Saves the current frame number
(BUTTON) Toggle Interpolation - this button is a toggle
	- If we are in Normal Mode and Interpolation is OFF : The normal animation is played
	- If we are in Normal Mode and Interpolation is ON : The interpolation is played
	- If we are in KeyFrameMode : The debug console will yell at you
(BUTTON) Reset Key Frames
	- Clears all of the current frames
	- If the program is currently in a mode dependent on those key frames, it will revert back to the normal mode
