This is a Visual Studio 2005 project. 
If you get errors like "FL/gl.h not found", then set the include path to fltk correctly:
select key_frame1, then Project -> Properties -> Configuration Properties -> C/C++ -> General -> Additional Include Directories -> navigate to the fltk project.